package EmpUtils;

public class Endpoints {

    public static final String EMPLOYEEENDPOINT = "employees" ;
    public static final String EMPLOYEEENDPOINT1 = "employee" ;
}
